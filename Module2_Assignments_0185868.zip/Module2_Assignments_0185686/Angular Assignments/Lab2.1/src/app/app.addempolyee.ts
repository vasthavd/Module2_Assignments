import{Component} from '@angular/core';


@Component
(
    {
        selector:'add-emp',
        templateUrl:'app.add.html'
    }
)

export class AddEmployeeComponent{

    empId:any;
    empName:string;
    empSalary:any;
    empDep:string;
    
    empobj:AddEmployeeComponent;
    upall:any[]=[];
    empAll:any[]=[
        {empId:1001,empName:"ABCD",empSalary:33333.11,empDep:"Java"},
        {empId:1002,empName:"BCD",empSalary:33333.11,empDep:"Java"},
        {empId:1003,empName:"CD",empSalary:33333.11,empDep:"Java"}
    ];
    data1:number;
    addEmployee():any{
      
        this.empAll.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDep:this.empDep})
        console.log("Employee Added...."+this.empAll);
        

    }
    deleteEmployee(data:number):any{
       
        this.empAll.splice(data,1);
    }
    empi:any;
    empn:string;
    emps:any;
    empd:string;
    datat1:number;
    searchEmployee(data:number):any{
      this.empi=this.empAll[data].empId;
      this.empn=this.empAll[data].empName;
      this.emps=this.empAll[data].empSalary;
      this.empd=this.empAll[data].empDep;
      this.data1=data;
    }
    
     updateEmployee():any{
        
       if(this.data1!=null)
       this.empAll.splice(this.data1,1,{empId:this.empi,empName:this.empn,empSalary:this.emps,empDep:this.empd});
       
    }

}